
package com.fatec.bhaskarapoo;

import javax.swing.JOptionPane;


public class BhaskaraPOO {

    public static void main(String[] args) {
        conta conta = new conta();
        double [] valores = new double [3];
        for (int i=0; i< valores.length;i++)
        {
            valores [i]= Double.parseDouble(JOptionPane.showInputDialog("Digite o valor " + (i+1)+ "(a,b,c):"));
            
        }
        
    
    conta.setA(valores[0]);
    conta.setB(valores[1]);
    conta.setC(valores[2]);
    
    conta.calcular();
    JOptionPane.showMessageDialog(null,
            "Delta: " +conta.getdelta()+
            "x1: " +conta.getx1()+
            "x2: " +conta.getx2());    
        }
    }
