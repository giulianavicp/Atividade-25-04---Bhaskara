package com.fatec.bhaskarapoo;

class conta {
    private double a;
    private double b;
    private double c;
    private double delta;
    private double x1;
    private double x2;
    
    public void calcular(){
        this.delta=(b*b)-(4*a*c);
        
        if (delta<0){
            System.out.println("Não existem raízes reais");
        }else{
            this.x1=(-b+Math.sqrt(delta))/(2*a);
            this.x2=(-b-Math.sqrt(delta))/(2*a);
            
        }
    }

    public double getA() {return a;}
    public void setA(double a) {this.a = a;}

    public double getB() {return b;}
    public void setB(double b) {this.b = b;}

    public double getC() {return c;}
    public void setC(double c) {this.c = c;}

    public double getDelta() {return delta;}
    public void setDelta(double delta) {this.delta = delta;}

    public double getX1() {return x1;}
    public double getX2() {return x2;}

    String getdelta() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getx1() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getx2() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
}

//Professor, o math.sqrt eu acabei pesquisando como fazer esta parte